package com.example.parkeunjeong.mycoordinator;

import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class SearchWeatherActivity extends AppCompatActivity {
    Handler handler = new Handler();
    EditText editTextCityName;
    Button search_b;
    Intent intent;
    TextView result1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_weather);

        editTextCityName = (EditText) findViewById(R.id.search_edit);
        result1 = (TextView)findViewById(R.id.textView4);
       // input01 = (EditText)findViewById(R.id.search_edit);

        search_b =(Button)findViewById(R.id.search_btn);
        search_b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String urlStr = editTextCityName.getText().toString();

                ConnectThread thread = new ConnectThread(urlStr);
                thread.start();
            }
        });
    }

  //  public void SearchClicked(View view) {
      //  String urlStr = input01.getText().toString();
      ///  ConnectThread thread = new ConnectThread("http://api.openweathermap.org/data/2.5/weather?q="+urlStr+"&APPID=fd7e31057231b1c292cd31ad30e536e6");
      //  thread.start();
  //  }

    public class ConnectThread extends Thread {
        OkHttpClient client = new OkHttpClient();
        String city;

        public ConnectThread(String inStr) {
            city = inStr;
        }

        public void run() {

            try {
                Request request = new Request.Builder()
                        .url("http://api.openweathermap.org/data/2.5/weather?q="+city+"&APPID="+"563ac7f8d9170be773ad9e9a0f2194c8")
                        .build();
                Response response = client.newCall(request).execute();
                JSONObject jsonObject = new JSONObject(response.body().string());
                final String output = "온도 : "+ ((JSONObject)jsonObject.get("main")).getString("temp");

                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        result1.setText(output);
                    }
                });

                //Response response = client.newCall(request).execute();
                //JSONObject jsonObject = new JSONObject(response.body().toString());
                //final String tem =  jsonObject.getString("main");

                //final int temp = Integer.parseInt(tem);

                //handler.post(new Runnable() {
                 //   @Override
                  //  public void run() {
                    //   result1.setText(tem);
                   // }
               // });

            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
}
